ARO_ROOT = "~/.cache/prerelease_bow"
COCO_ROOT = "~/.cache/coco/2014"
FLICKR_ROOT = "~/.cache/flick30k/images"
