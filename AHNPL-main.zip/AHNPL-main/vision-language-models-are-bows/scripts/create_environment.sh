python -m pip install ftfy>=6.1.1
python -m pip install git+https://github.com/openai/CLIP.git
python -m pip install easydict
python -m pip install PyYAML fairscale>=0.4.13
python -m pip install open-clip-torch==2.11.1
python -m pip install torch>=1.13.1 torchvision>=0.14.1 --extra-index-url https://download.pytorch.org/whl/cu116
python -m pip install nltk>=3.7
python -m pip install spacy>=3.1.1
python -m pip install numpy>=1.23.5
python -m pip install transformers>=4.26.0
python -m pip install tqdm
python -m pip install pandas>=1.4.3
python -m pip install scikit-learn>=1.2.0
python -m pip install scipy>=1.7.3
