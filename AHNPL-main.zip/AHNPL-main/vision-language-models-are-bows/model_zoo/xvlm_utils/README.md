Most of the utilities here are obtained from https://github.com/zengyan-97/X-VLM/
