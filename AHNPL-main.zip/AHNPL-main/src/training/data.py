import ast
import json
import logging
import math
import os
import random
import sys
import time
from dataclasses import dataclass
from multiprocessing import Value
from transformers import CLIPProcessor
import numpy as np
import pandas as pd
import torch
import torchvision.datasets as datasets
import webdataset as wds
from pathlib import Path
from PIL import Image
from torch.utils.data import Dataset, DataLoader, SubsetRandomSampler, IterableDataset, get_worker_info
from torch.utils.data.distributed import DistributedSampler
from webdataset.filters import _shuffle
from webdataset.tariterators import base_plus_ext, url_opener, tar_file_expander, valid_sample
import glob
from PIL import ImageFile
from pycocotools.coco import COCO
ImageFile.LOAD_TRUNCATED_IMAGES = True
from datasets import load_dataset
try:
    import horovod.torch as hvd
except ImportError:
    hvd = None
COCO_DATASET_ROOT = os.getenv('IMG_DATA_DIR', '~/coco/train2014')

class WinogroundDataCollator_batched:

    def __init__(self):
        self.processor = CLIPProcessor.from_pretrained('openai/clip-vit-base-patch32')

    def __call__(self, batch):
        text = []
        images = []
        for example in batch:
            text.extend([example['caption_0'], example['caption_1']])
            images.extend([example['image_0'].convert('RGB'), example['image_1'].convert('RGB')])
        return self.processor(text=text, images=images, return_tensors='pt', padding=True)

class SharedEpoch:

    def __init__(self, epoch: int=0):
        self.shared_epoch = Value('i', epoch)

    def set_value(self, epoch):
        self.shared_epoch.value = epoch

    def get_value(self):
        return self.shared_epoch.value

@dataclass
class DataInfo:
    dataloader: DataLoader
    sampler: DistributedSampler = None
    shared_epoch: SharedEpoch = None

    def set_epoch(self, epoch):
        if self.shared_epoch is not None:
            self.shared_epoch.set_value(epoch)
        if self.sampler is not None and isinstance(self.sampler, DistributedSampler):
            self.sampler.set_epoch(epoch)

def get_dataset_size(shards):
    shards_list = wds.shardlists.expand_urls(shards)
    dir_path = os.path.dirname(shards_list[0])
    sizes_filename = os.path.join(dir_path, 'sizes.json')
    len_filename = os.path.join(dir_path, '__len__')
    if os.path.exists(sizes_filename):
        sizes = json.load(open(sizes_filename, 'r'))
        total_size = sum([int(sizes[os.path.basename(shard)]) for shard in shards_list])
    elif os.path.exists(len_filename):
        total_size = ast.literal_eval(open(len_filename, 'r').read())
    else:
        total_size = None
    num_shards = len(shards_list)
    return (total_size, num_shards)

def get_imagenet(args, preprocess_fns, split):
    assert split in ['train', 'val', 'v2']
    is_train = split == 'train'
    (preprocess_train, preprocess_val) = preprocess_fns
    if split == 'v2':
        from imagenetv2_pytorch import ImageNetV2Dataset
        dataset = ImageNetV2Dataset(location=args.imagenet_v2, transform=preprocess_val)
    else:
        if is_train:
            data_path = args.imagenet_train
            preprocess_fn = preprocess_train
        else:
            data_path = args.imagenet_val
            preprocess_fn = preprocess_val
        assert data_path
        dataset = datasets.ImageFolder(data_path, transform=preprocess_fn)
    if is_train:
        idxs = np.zeros(len(dataset.targets))
        target_array = np.array(dataset.targets)
        k = 50
        for c in range(1000):
            m = target_array == c
            n = len(idxs[m])
            arr = np.zeros(n)
            arr[:k] = 1
            np.random.shuffle(arr)
            idxs[m] = arr
        idxs = idxs.astype('int')
        sampler = SubsetRandomSampler(np.where(idxs)[0])
    else:
        sampler = None
    dataloader = torch.utils.data.DataLoader(dataset, batch_size=args.batch_size, num_workers=args.workers, sampler=sampler)
    return DataInfo(dataloader=dataloader, sampler=sampler)

def count_samples(dataloader):
    os.environ['WDS_EPOCH'] = '0'
    (n_elements, n_batches) = (0, 0)
    for (images, texts) in dataloader:
        n_batches += 1
        n_elements += len(images)
        assert len(images) == len(texts)
    return (n_elements, n_batches)

def filter_no_caption_or_no_image(sample):
    has_caption = 'txt' in sample
    has_image = 'png' in sample or 'jpg' in sample or 'jpeg' in sample or ('webp' in sample)
    return has_caption and has_image

def log_and_continue(exn):
    logging.warning(f'Handling webdataset error ({repr(exn)}). Ignoring.')
    return True

def group_by_keys_nothrow(data, keys=base_plus_ext, lcase=True, suffixes=None, handler=None):
    current_sample = None
    for filesample in data:
        assert isinstance(filesample, dict)
        (fname, value) = (filesample['fname'], filesample['data'])
        (prefix, suffix) = keys(fname)
        if prefix is None:
            continue
        if lcase:
            suffix = suffix.lower()
        if current_sample is None or prefix != current_sample['__key__'] or suffix in current_sample:
            if valid_sample(current_sample):
                yield current_sample
            current_sample = dict(__key__=prefix, __url__=filesample['__url__'])
        if suffixes is None or suffix in suffixes:
            current_sample[suffix] = value
    if valid_sample(current_sample):
        yield current_sample

def tarfile_to_samples_nothrow(src, handler=log_and_continue):
    streams = url_opener(src, handler=handler)
    files = tar_file_expander(streams, handler=handler)
    samples = group_by_keys_nothrow(files, handler=handler)
    return samples

def pytorch_worker_seed(increment=0):
    worker_info = get_worker_info()
    if worker_info is not None:
        seed = worker_info.seed
        if increment:
            seed += increment * max(1, worker_info.num_workers)
        return seed
    return wds.utils.pytorch_worker_seed()
_SHARD_SHUFFLE_SIZE = 2000
_SHARD_SHUFFLE_INITIAL = 500
_SAMPLE_SHUFFLE_SIZE = 5000
_SAMPLE_SHUFFLE_INITIAL = 1000

class detshuffle2(wds.PipelineStage):

    def __init__(self, bufsize=1000, initial=100, seed=0, epoch=-1):
        self.bufsize = bufsize
        self.initial = initial
        self.seed = seed
        self.epoch = epoch

    def run(self, src):
        if isinstance(self.epoch, SharedEpoch):
            epoch = self.epoch.get_value()
        else:
            self.epoch += 1
            epoch = self.epoch
        rng = random.Random()
        if self.seed < 0:
            seed = pytorch_worker_seed(epoch)
        else:
            seed = self.seed + epoch
        rng.seed(seed)
        return _shuffle(src, self.bufsize, self.initial, rng)

class ResampledShards2(IterableDataset):

    def __init__(self, urls, nshards=sys.maxsize, worker_seed=None, deterministic=False, epoch=-1):
        super().__init__()
        urls = wds.shardlists.expand_urls(urls)
        self.urls = urls
        assert isinstance(self.urls[0], str)
        self.nshards = nshards
        self.rng = random.Random()
        self.worker_seed = worker_seed
        self.deterministic = deterministic
        self.epoch = epoch

    def __iter__(self):
        if isinstance(self.epoch, SharedEpoch):
            epoch = self.epoch.get_value()
        else:
            self.epoch += 1
            epoch = self.epoch
        if self.deterministic:
            if self.worker_seed is None:
                seed = pytorch_worker_seed(epoch)
            else:
                seed = self.worker_seed() + epoch
            self.rng.seed(seed)
        for _ in range(self.nshards):
            yield dict(url=self.rng.choice(self.urls))

def get_wds_dataset(args, preprocess_img, is_train, epoch=0, floor=False, tokenizer=None):
    input_shards = args.train_data if is_train else args.val_data
    assert input_shards is not None
    resampled = getattr(args, 'dataset_resampled', False) and is_train
    (num_samples, num_shards) = get_dataset_size(input_shards)
    if not num_samples:
        if is_train:
            num_samples = args.train_num_samples
            if not num_samples:
                raise RuntimeError('Currently, number of dataset samples must be specified for training dataset. Please specify via `--train-num-samples` if no dataset length info present.')
        else:
            num_samples = args.val_num_samples or 0
    shared_epoch = SharedEpoch(epoch=epoch)
    if resampled:
        pipeline = [ResampledShards2(input_shards, deterministic=True, epoch=shared_epoch)]
    else:
        pipeline = [wds.SimpleShardList(input_shards)]
    if is_train:
        if not resampled:
            pipeline.extend([detshuffle2(bufsize=_SHARD_SHUFFLE_SIZE, initial=_SHARD_SHUFFLE_INITIAL, seed=args.seed, epoch=shared_epoch), wds.split_by_node, wds.split_by_worker])
        pipeline.extend([tarfile_to_samples_nothrow, wds.shuffle(bufsize=_SAMPLE_SHUFFLE_SIZE, initial=_SAMPLE_SHUFFLE_INITIAL)])
    else:
        pipeline.extend([wds.split_by_worker, wds.tarfile_to_samples(handler=log_and_continue)])
    pipeline.extend([wds.select(filter_no_caption_or_no_image), wds.decode('pilrgb', handler=log_and_continue), wds.rename(image='jpg;png;jpeg;webp', text='txt'), wds.map_dict(image=preprocess_img, text=lambda text: tokenizer(text)[0]), wds.to_tuple('image', 'text'), wds.batched(args.batch_size, partial=not is_train)])
    dataset = wds.DataPipeline(*pipeline)
    if is_train:
        if not resampled:
            assert num_shards >= args.workers * args.world_size, 'number of shards must be >= total workers'
        round_fn = math.floor if floor else math.ceil
        global_batch_size = args.batch_size * args.world_size
        num_batches = round_fn(num_samples / global_batch_size)
        num_workers = max(1, args.workers)
        num_worker_batches = round_fn(num_batches / num_workers)
        num_batches = num_worker_batches * num_workers
        num_samples = num_batches * global_batch_size
        dataset = dataset.with_epoch(num_worker_batches)
    else:
        num_batches = math.ceil(num_samples / args.batch_size)
    dataloader = wds.WebLoader(dataset, batch_size=None, shuffle=False, num_workers=args.workers, persistent_workers=True)
    dataloader.num_batches = num_batches
    dataloader.num_samples = num_samples
    return DataInfo(dataloader=dataloader, shared_epoch=shared_epoch)

class CsvDataset(Dataset):

    def __init__(self, input_filename, transforms, img_key, caption_key, sep='\t', tokenizer=None):
        logging.debug(f'Loading csv data from {input_filename}.')
        df = pd.read_csv(input_filename, sep=sep)
        self.images = df[img_key].tolist()
        self.captions = df[caption_key].tolist()
        self.transforms = transforms
        logging.debug('Done loading data.')
        self.tokenize = tokenizer

    def __len__(self):
        return len(self.captions)

    def __getitem__(self, idx):
        images = self.transforms(Image.open(str(self.images[idx])))
        texts = self.tokenize([str(self.captions[idx])])[0]
        return (images, texts)

class NpyDataset(Dataset):

    def __init__(self, samples_path, transforms=None, train_num_samples=None, tokenizer=None, split=None):
        if split == None:
            if 'val' in samples_path:
                self.split = 'val'
            else:
                self.split = 'train'
        else:
            self.split = split
        if 'coco' in samples_path:
            self.data = 'coco'
        else:
            self.data = 'cc3m'
        if os.path.isdir(samples_path):
            data_file_splits = glob.glob(os.path.join(samples_path, '*.npy'))
            print(f'merging {len(data_file_splits)} splied files from {samples_path}')
            self.samples = []
            for file_split in data_file_splits:
                self.samples.extend(self.loadList(file_split))
        else:
            self.samples = self.loadList(samples_path)
        if train_num_samples:
            self.samples = self.samples[:train_num_samples]
        self.transforms = transforms
        self.tokenize = tokenizer

    def loadList(self, file_path):
        tempNumpyArray = np.load(file_path, allow_pickle=True)
        return tempNumpyArray.tolist()

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        captions = torch.stack([self.tokenize([str(self.samples[index]['caption'])])[0], self.tokenize([str(self.samples[index]['relation_aug_caption'])])[0], self.tokenize([str(self.samples[index]['adj_swap_aug_caption'])])[0], self.tokenize([str(self.samples[index]['adj_aug_caption'])])[0], self.tokenize([str(self.samples[index]['noun_aug_caption'])])[0], self.tokenize([str(self.samples[index]['verb_aug_caption'])])[0]])
        if self.data == 'coco':
            image_id = self.samples[index]['image_id']
            data_split = 'train2014' if self.split == 'train' else 'val2014'
            image_path = os.path.join(COCO_DATASET_ROOT, data_split, f"COCO_{data_split}_{'0' * (12 - len(str(image_id)))}{image_id}.jpg")
            image = self.transforms(Image.open(image_path).convert('RGB'))
        else:
            image = self.transforms(Image.open(str(self.samples[index]['image_path'])).convert('RGB'))
        valid_caption_mask = torch.tensor(self.samples[index]['valid_caption'])
        return (image, captions, valid_caption_mask)

class HardNegative_Collate:

    def __call__(self, batch):
        img = torch.stack([example[0] for example in batch])
        ture_caption = torch.stack([example[1][0] for example in batch])
        hard_negative = torch.cat([example[1][1:] for example in batch])
        text = torch.cat([ture_caption, hard_negative])
        valid_caption_mask = torch.stack([example[2] for example in batch])
        return (img, text, valid_caption_mask)

class Winoground(Dataset):

    def __init__(self, transforms, tokenizer=None):
        auth_token = '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'
        self.dataset = load_dataset('facebook/winoground', use_auth_token=auth_token)['test']
        self.transforms = transforms
        self.tokenize = tokenizer

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, index):
        images = torch.stack([self.transforms(self.dataset[index]['image_0']), self.transforms(self.dataset[index]['image_1'])], dim=0)
        texts = torch.stack([self.tokenize(self.dataset[index]['caption_0'])[0], self.tokenize(self.dataset[index]['caption_1'])[0]], dim=0)
        return (images, texts)

class Winoground_Collate:

    def __call__(self, batch):
        img = torch.cat([example[0] for example in batch])
        text = torch.cat([example[1] for example in batch])
        return (img, text)

def get_npy_dataset(args, preprocess_fn, is_train, epoch=0, tokenizer=None):
    input_filename = args.train_data if is_train else args.val_data
    assert input_filename
    dataset = NpyDataset(input_filename, preprocess_fn, tokenizer=tokenizer, train_num_samples=args.train_num_samples)
    num_samples = len(dataset)
    sampler = DistributedSampler(dataset) if args.distributed and is_train else None
    shuffle = is_train and sampler is None
    collate = HardNegative_Collate()
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=shuffle, num_workers=args.workers, pin_memory=True, sampler=sampler, drop_last=is_train, collate_fn=collate)
    dataloader.num_samples = num_samples
    dataloader.num_batches = len(dataloader)
    return DataInfo(dataloader, sampler)

def get_csv_dataset(args, preprocess_fn, is_train, epoch=0, tokenizer=None):
    input_filename = args.train_data if is_train else args.val_data
    assert input_filename
    dataset = CsvDataset(input_filename, preprocess_fn, img_key=args.csv_img_key, caption_key=args.csv_caption_key, sep=args.csv_separator, tokenizer=tokenizer)
    num_samples = len(dataset)
    sampler = DistributedSampler(dataset) if args.distributed and is_train else None
    shuffle = is_train and sampler is None
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=shuffle, num_workers=args.workers, pin_memory=True, sampler=sampler, drop_last=is_train)
    dataloader.num_samples = num_samples
    dataloader.num_batches = len(dataloader)
    return DataInfo(dataloader, sampler)

class Coco_Collate:

    def __call__(self, batch):
        img = torch.cat([example[0] for example in batch])
        text = torch.cat([example[1] for example in batch])
        return (img, text)

class CocoDataset(Dataset):

    def __init__(self, root, json, transforms, tokenizer=None):
        self.root = root
        self.dataset = COCO(json)
        self.ids = list(self.dataset.anns.keys())
        self.transforms = transforms
        self.tokenize = tokenizer

    def __getitem__(self, index):
        dataset = self.dataset
        ann_id = self.ids[index]
        caption = dataset.anns[ann_id]['caption']
        img_id = dataset.anns[ann_id]['image_id']
        path = dataset.loadImgs(img_id)[0]['file_name']
        image = Image.open(os.path.join(self.root, path)).convert('RGB')
        if self.transforms is not None:
            image = self.transforms(image)
        caption = self.tokenize(caption)[0]
        return (image, caption)

    def __len__(self):
        return len(self.ids)

def get_json_dataset(args, preprocess_fn, is_train, epoch=0, tokenizer=None):
    input_filename = args.train_data if is_train else args.val_data
    if 'coco' in input_filename:
        images_root = os.path.join(COCO_DATASET_ROOT, 'train2014' if is_train else 'val2014')
        dataset = CocoDataset(images_root, input_filename, preprocess_fn, tokenizer)
    else:
        raise ValueError('currently only support COCO Dataset')
    num_samples = len(dataset)
    sampler = DistributedSampler(dataset) if args.distributed and is_train else None
    shuffle = is_train and sampler is None
    collate = Coco_Collate()
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=shuffle, pin_memory=True, sampler=sampler, drop_last=is_train)
    dataloader.num_samples = num_samples
    dataloader.num_batches = len(dataloader)
    return DataInfo(dataloader, sampler)

class SyntheticDataset(Dataset):

    def __init__(self, transform=None, image_size=(224, 224), caption='Dummy caption', dataset_size=100, tokenizer=None):
        self.transform = transform
        self.image_size = image_size
        self.caption = caption
        self.image = Image.new('RGB', image_size)
        self.dataset_size = dataset_size
        self.preprocess_txt = lambda text: tokenizer(text)[0]

    def __len__(self):
        return self.dataset_size

    def __getitem__(self, idx):
        if self.transform is not None:
            image = self.transform(self.image)
        return (image, self.preprocess_txt(self.caption))

def get_synthetic_dataset(args, preprocess_fn, is_train, epoch=0, tokenizer=None):
    image_size = preprocess_fn.transforms[0].size
    dataset = SyntheticDataset(transform=preprocess_fn, image_size=image_size, dataset_size=args.train_num_samples, tokenizer=tokenizer)
    num_samples = len(dataset)
    sampler = DistributedSampler(dataset) if args.distributed and is_train else None
    shuffle = is_train and sampler is None
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=shuffle, num_workers=args.workers, pin_memory=True, sampler=sampler, drop_last=is_train)
    dataloader.num_samples = num_samples
    dataloader.num_batches = len(dataloader)
    return DataInfo(dataloader, sampler)

def get_huggingface_dataset(args, preprocess_fn, is_train, epoch=0, tokenizer=None):
    if args.val_data == 'winoground':
        dataset = Winoground(transforms=preprocess_fn, tokenizer=tokenizer)
        collate = Winoground_Collate()
    else:
        raise ValueError('must specify dataset name for huggingface dataset type')
    num_samples = len(dataset)
    sampler = DistributedSampler(dataset) if args.distributed and is_train else None
    shuffle = is_train and sampler is None
    dataloader = DataLoader(dataset, batch_size=args.batch_size, shuffle=shuffle, pin_memory=True, sampler=sampler, drop_last=is_train, collate_fn=collate)
    dataloader.num_samples = num_samples
    dataloader.num_batches = len(dataloader)
    return DataInfo(dataloader, sampler)

def get_dataset_fn(data_path, dataset_type):
    if dataset_type == 'huggingface' or data_path == 'winoground':
        return get_huggingface_dataset
    elif dataset_type == 'webdataset':
        return get_wds_dataset
    elif dataset_type == 'csv':
        return get_csv_dataset
    elif dataset_type == 'synthetic':
        return get_synthetic_dataset
    elif dataset_type == 'npy':
        return get_npy_dataset
    elif dataset_type == 'json':
        return get_json_dataset
    elif dataset_type == 'auto':
        ext = data_path.split('.')[-1]
        if ext in ['csv', 'tsv']:
            return get_csv_dataset
        elif ext in ['tar']:
            return get_wds_dataset
        else:
            raise ValueError(f'Tried to figure out dataset type, but failed for extension {ext}.')
    else:
        raise ValueError(f'Unsupported dataset type: {dataset_type}')

def get_data(args, preprocess_fns, epoch=0, tokenizer=None):
    (preprocess_train, preprocess_val) = preprocess_fns
    data = {}
    if args.train_data or args.dataset_type == 'synthetic':
        data['train'] = get_dataset_fn(args.train_data, args.dataset_type)(args, preprocess_train, is_train=True, epoch=epoch, tokenizer=tokenizer)
    if args.val_data:
        data['val'] = get_dataset_fn(args.val_data, args.dataset_type)(args, preprocess_val, is_train=False, tokenizer=tokenizer)
    if args.imagenet_val is not None:
        data['imagenet-val'] = get_imagenet(args, preprocess_fns, 'val')
    if args.imagenet_v2 is not None:
        data['imagenet-v2'] = get_imagenet(args, preprocess_fns, 'v2')
    return data